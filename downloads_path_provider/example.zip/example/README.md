# downloads_path_provider_example

Demonstrates how to use the downloads_path_provider plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
